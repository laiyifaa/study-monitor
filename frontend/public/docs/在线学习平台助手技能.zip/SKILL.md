---
name: study-monitor
description: 接入"在线学习平台"系统，替教师自动执行学生进度查询、统计汇总、发送提醒、导出报表、创建课程、上传视频等操作。触发词：学习进度、学生完成情况、网课统计、课程完成率、学习提醒、导出报表、创建课程、上传视频、study monitor。当用户要求查看/汇报/统计学生的学习情况，或要求代为执行学习平台操作时使用。
name_cn: 在线学习平台助手
description_cn: 接入在线学习平台，自动查询学生进度、汇总统计、发送提醒、导出报表、创建课程、上传视频
create_source: super-agent-skill-creator
---

# 在线学习平台助手

替教师操作"在线学习平台"，自动完成课程创建、视频上传、学生进度查询、统计汇总、提醒推送、报表导出等日常操作。

## 接入配置

本技能需要用户提供以下信息才能工作：

1. **服务器地址**（如 `http://localhost:8000` 或 `https://your-domain.com`）
2. **API Key**（由教师在系统统计看板 → "智能体接入密钥" → 生成密钥 获取，格式 `sk_...`）

首次使用时，若用户未提供上述信息，主动询问。获取后在本会话内缓存复用。

## 认证方式

所有 API 请求携带请求头：

```
X-API-Key: <用户提供的API Key>
```

用 curl 或 Python httpx 调用即可，无需 JWT。

## 核心工作流

### 1. 查看学生完成情况（最常用）

**典型用户请求**："帮我看看学生学得怎么样"、"谁还没完成"、"统计一下完成率"

执行步骤：
1. `GET {server}/api/courses?status=active` — 获取课程列表
2. 对每门课程（或用户指定的课程）调用 `GET {server}/api/stats/class-overview?course_id={id}`
3. 汇总输出：
   - 每门课的完成率、已完成/未完成人数
   - 未完成学生名单及当前有效时长
   - 与要求时长的差距

输出格式示例：
```
📊 高中数学必修一 - 集合与函数（要求60分钟）
  完成率: 60% (3/5人)
  ✅ 已完成: 王小明(629分), 李小红(90分), 陈思思(90分)
  ⚠️ 未完成: 刘大伟(55分/差5分), 赵天宇(10分/差50分)
```

### 2. 查看今日学习动态

**典型用户请求**："今天有多少人在学"、"今日学习情况"

调用 `GET {server}/api/stats/daily-summary?course_id={id}`，输出今日学习人数、总有效时长、人均时长。

### 3. 发送学习提醒

**典型用户请求**："帮我催一下没完成的学生"、"给没学的发个提醒"

调用 `POST {server}/api/notify/study-reminder`，body: `{"course_id": id}`

### 4. 导出学习报表

**典型用户请求**："导出一份报表"、"生成Excel"

调用 `GET {server}/api/notify/export?course_id={id}`，保存为 `.xlsx` 文件。

### 5. 创建课程并上传视频（完整流程）

**典型用户请求**："帮我创建一门新课"、"建个课程传视频"、"新建课程XXX，要求学习90分钟"

这是最常用的创建流程，涉及课程 → 章节 → 视频三步。**必须按顺序执行**，不存在批量接口。

#### 步骤一：创建课程

```
POST {server}/api/courses
Body: {
  "title": "高中数学必修一 - 集合与函数",   // 必填
  "description": "暑期必修课程",              // 可选
  "require_minutes": 60,                      // 可选，默认60分钟
  "start_date": "2026-07-01T00:00:00",        // 可选
  "end_date": "2026-08-31T23:59:59"           // 可选
}
```

返回 `data.id` 即课程ID，后续步骤需要。

#### 步骤二（重复N次）：创建章节

每门课有N个章节（如"第1讲"、"第2讲"），逐个创建：

```
POST {server}/api/sections
Body: {
  "course_id": <步骤一返回的ID>,    // 必填
  "title": "第1讲 集合的概念",       // 必填
  "sort_order": 1,                   // 可选，排序序号，从1开始
  "video_type": "url",               // 可选，"url"=外链视频，"local"=本地上传，默认url
  "video_url": "https://...",        // video_type="url"时填写视频链接
  "duration_seconds": 1800,          // 可选，视频时长（秒）
  "open_time": "2026-07-05T09:00:00" // 可选，定时开放时间，null=无限制
}
```

返回 `data.id` 即章节ID。

#### 步骤三（仅本地视频需要）：上传视频文件

如果章节视频是本地文件（video_type="local"），创建章节后需要单独上传：

```
POST {server}/api/sections/{section_id}/upload-video
Content-Type: multipart/form-data
File field: file=<视频文件>
```

**上传约束**：
- 支持格式：`.mp4`、`.webm`、`.ogg`、`.mov`
- 最大 500MB
- 上传后自动设置 `video_type="local"` 并关联视频，无需额外操作
- 重复上传会替换旧视频

#### 完整示例：创建"高中数学必修一"含3个章节 + 本地视频

```
1. POST /api/courses → 返回 course_id=10

2. POST /api/sections → { course_id:10, title:"第1讲 集合的概念", sort_order:1 } → section_id=21
3. POST /api/sections/21/upload-video → file=集合的概念.mp4

4. POST /api/sections → { course_id:10, title:"第2讲 函数的性质", sort_order:2 } → section_id=22
5. POST /api/sections/22/upload-video → file=函数的性质.mp4

6. POST /api/sections → { course_id:10, title:"第3讲 综合练习", sort_order:3 } → section_id=23
7. POST /api/sections/23/upload-video → file=综合练习.mp4
```

#### 外链视频（悟空/第三方平台）更简单

如果视频已在外部平台（如钉钉悟空），只需在步骤二直接填 `video_type:"url"` + `video_url`，无需步骤三：

```
POST /api/sections → { course_id:10, title:"第1讲 集合", sort_order:1, video_type:"url", video_url:"https://wukong.dingtalk.com/..." }
```

#### 注意事项

- 课程创建者自动成为该课程的教师
- `sort_order` 决定章节显示顺序，数值越小越靠前
- `open_time` 可控制章节定时开放（未到时间学生看不到）
- 上传视频较慢时（大文件），需设置较长超时（建议10分钟）

### 6. 章节/视频管理

**典型用户请求**："修改章节标题"、"替换某个视频"、"删掉第3讲"

- 查看课程章节: `GET {server}/api/sections?course_id={id}`
- 修改章节信息: `PUT {server}/api/sections/{id}` body: `{"title": "新标题", "duration_seconds": 3600}`
- 替换视频: `POST {server}/api/sections/{id}/upload-video` file=<新视频>（自动替换旧视频）
- 切换为外链视频: `PUT {server}/api/sections/{id}` body: `{"video_type": "url", "video_url": "https://..."}`
- 删除章节: `DELETE {server}/api/sections/{id}`（同时删除本地视频文件）

### 7. 课程管理

**典型用户请求**："修改课程时长要求"、"结束一门课"

- 修改课程: `PUT {server}/api/courses/{id}` body: `{"require_minutes": 90, "status": "ended"}`
- 删除课程: `DELETE {server}/api/courses/{id}`（仅管理员，级联删除所有章节和视频）

### 8. 用户管理

**典型用户请求**："添加一个老师"、"把某某改成教师"、"重置学生密码"

- 查看用户: `GET {server}/api/admin/users?role=student`
- 改角色: `PUT {server}/api/admin/users/{id}/role` body: `{"role": "teacher"}`
- 设密码: `POST {server}/api/admin/users/{id}/reset-password` body: `{"new_password": "123456"}`
- 新增用户: `POST {server}/api/admin/users` body: `{"name": "xxx", "role": "teacher", "password": "123456"}`
- 更新用户: `PUT {server}/api/admin/users/{id}` body: `{"class_name": "高一1班", "phone": "13800138000"}`

### 9. 班级管理

**典型用户请求**："创建一个班级"、"把学生分到班"、"查看有哪些班级"

#### 创建班级

```
POST {server}/api/admin/classes
Body: { "class_name": "2026级高一新生" }
```

支持空班级——创建后无需立即分配学生，班级即可出现在列表中。

#### 批量分配学生到班级

```
PUT {server}/api/admin/classes/{class_name}/students
Body: { "user_ids": [848, 849, 850, ...] }
```

先通过 `GET {server}/api/admin/users?role=student` 获取学生ID列表，再批量分配。已在其他班级的学生会被移动到新班级。

#### 查看班级列表

```
GET {server}/api/admin/classes
```

返回每个班级的学生数和教师数，含空班级。

#### 重命名班级（仅管理员）

```
PUT {server}/api/admin/classes/{old_name}
Body: { "new_name": "新班级名" }
```

#### 删除班级（仅管理员）

```
DELETE {server}/api/admin/classes/{class_name}
```

将班级内所有用户的 class_name 置空，并删除班级记录。不删除用户和学习数据。

## API 完整参考

详见 [references/api-reference.md](references/api-reference.md) — 当需要调用的接口不在上述工作流中时，读取此文件获取完整接口文档。

## 输出规范

- 统计数据用中文呈现，附emoji增强可读性（✅⚠️📊）
- 学生姓名和时长并列展示
- 未完成学生标注与要求的差距
- 操作结果简明反馈（"已发送提醒"、"已导出到 xxx.xlsx"）
- 遇到 401 错误提示用户检查 API Key 是否有效
- 遇到 403 错误说明当前 Key 权限不足
