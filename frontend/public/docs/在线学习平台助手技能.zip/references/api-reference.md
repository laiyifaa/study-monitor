---
AIGC:
  ContentProducer: '001191110102MAD55U9H0F10002'
  ContentPropagator: '001191110102MAD55U9H0F10002'
  Label: '1'
  ProduceID: '49e3ed47-b1e1-41f9-b52f-b30082a263ca'
  PropagateID: '49e3ed47-b1e1-41f9-b52f-b30082a263ca'
  ReservedCode1: 'd9d04b52-5690-4b09-b13f-2e03b9d02095'
  ReservedCode2: 'd9d04b52-5690-4b09-b13f-2e03b9d02095'
---

# Study Monitor API Reference

> 22中暑假网课学习进度监督系统 — 智能体接入 API 文档

## 认证方式

所有 API 支持 `X-API-Key` 请求头认证，格式：

```
X-API-Key: sk_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

API Key 由教师/管理员在系统统计看板页面生成，拥有与生成者相同的权限。

---

## 课程相关

### GET /api/courses

获取课程列表。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| status | query | 否 | `active`=进行中, `ended`=已结束, `draft`=草稿 |

返回示例：
```json
{
  "code": 0,
  "data": [
    {
      "id": 1,
      "title": "高中数学必修一 - 集合与函数",
      "description": "...",
      "require_minutes": 60,
      "status": "active",
      "start_date": "2026-06-01T00:00:00",
      "end_date": "2026-08-31T00:00:00"
    }
  ]
}
```

### POST /api/courses

创建课程（教师/管理员）。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| title | body | 是 | 课程标题 |
| description | body | 否 | 课程描述 |
| require_minutes | body | 否 | 要求学习时长（分钟），默认60 |
| start_date | body | 否 | 开始日期（ISO格式） |
| end_date | body | 否 | 截止日期（ISO格式） |

返回示例：
```json
{
  "code": 0,
  "data": { "id": 10, "title": "高中数学必修一 - 集合与函数" }
}
```

### PUT /api/courses/{course_id}

更新课程信息（教师/管理员）。所有字段可选。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| title | body | 否 | 课程标题 |
| description | body | 否 | 课程描述 |
| require_minutes | body | 否 | 要求学习时长（分钟） |
| start_date | body | 否 | 开始日期 |
| end_date | body | 否 | 截止日期 |
| status | body | 否 | `active`/`ended`/`draft` |

### DELETE /api/courses/{course_id}

删除课程（仅管理员）。级联删除课程下所有章节及本地视频文件。

---

## 章节相关

### GET /api/sections

获取章节列表。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| course_id | query | 是 | 课程ID |

返回示例：
```json
{
  "code": 0,
  "data": [
    {
      "id": 21,
      "course_id": 10,
      "title": "第1讲 集合的概念",
      "sort_order": 1,
      "video_type": "local",
      "video_url": "s_21_a1b2c3d4.mp4",
      "video_cdn_url": "https://cdn.example.com/uploads/videos/s_21_a1b2c3d4.mp4",
      "duration_seconds": 1800,
      "open_time": null
    }
  ]
}
```

> `video_cdn_url` 仅在 `video_type="local"` 且服务器配置了 CDN_DOMAIN 时返回。

### POST /api/sections

创建章节（教师/管理员）。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| course_id | body | 是 | 所属课程ID |
| title | body | 是 | 章节标题（如"第1讲 集合的概念"） |
| sort_order | body | 否 | 排序序号，从小到大，默认0 |
| video_type | body | 否 | `url`=外链 / `local`=本地上传，默认url |
| video_url | body | 否 | 外链视频地址（video_type="url"时填写） |
| duration_seconds | body | 否 | 视频时长（秒），默认0 |
| open_time | body | 否 | 定时开放时间（ISO格式），null=无限制 |

返回示例：
```json
{
  "code": 0,
  "data": { "id": 21, "title": "第1讲 集合的概念" }
}
```

### GET /api/sections/{section_id}

获取单个章节详情。

### PUT /api/sections/{section_id}

更新章节信息（教师/管理员）。所有字段可选。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| title | body | 否 | 章节标题 |
| sort_order | body | 否 | 排序序号 |
| video_type | body | 否 | `url`/`local` |
| video_url | body | 否 | 视频地址 |
| duration_seconds | body | 否 | 视频时长（秒） |
| open_time | body | 否 | 定时开放时间，null清除限制 |

### DELETE /api/sections/{section_id}

删除章节（教师/管理员）。同时删除本地视频文件（如 video_type="local"）。

### POST /api/sections/{section_id}/upload-video

上传视频文件到章节（教师/管理员）。Content-Type: multipart/form-data。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| section_id | path | 是 | 目标章节ID（章节必须已存在） |
| file | form | 是 | 视频文件 |

**上传约束：**
- 支持格式：`.mp4`、`.webm`、`.ogg`、`.mov`
- 最大文件大小：500MB
- 文件存储在服务器 `uploads/videos/` 目录
- 文件命名格式：`s_{section_id}_{uuid8}.{ext}`（如 `s_21_a1b2c3d4.mp4`）
- 重复上传自动替换旧视频文件
- 上传成功后自动设置 `video_type="local"` 和 `video_url=<filename>`

返回示例：
```json
{
  "code": 0,
  "data": { "video_type": "local", "video_url": "s_21_a1b2c3d4.mp4" }
}
```

**视频关联方式总结：**

| 方式 | 操作 | 适用场景 |
|------|------|----------|
| 创建章节时指定 | POST /api/sections 设置 video_type+video_url | 外链视频，创建时已有URL |
| 上传视频文件 | POST /api/sections/{id}/upload-video | 本地视频文件 |
| 更新章节信息 | PUT /api/sections/{id} 设置 video_type+video_url | 后续修改或切换视频源 |

---

## 统计相关

### GET /api/stats/class-overview

班级统计概览（教师/管理员最常用接口）。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| course_id | query | 是 | 课程ID |

返回示例：
```json
{
  "code": 0,
  "data": {
    "course_title": "高中数学必修一 - 集合与函数",
    "require_minutes": 60,
    "total_students": 5,
    "completed_students": 3,
    "completion_rate": 0.6,
    "students": [
      {
        "user_id": 2,
        "name": "王小明",
        "class_name": "高一1班",
        "effective_minutes": 629.5,
        "require_minutes": 60,
        "completion_rate": 1.0,
        "is_completed": true
      }
    ]
  }
}
```

### GET /api/stats/my-progress

查看我的学习进度（学生视角）。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| course_id | query | 是 | 课程ID |

### GET /api/stats/daily-summary

每日学习统计。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| course_id | query | 是 | 课程ID |

返回：`active_students`, `total_effective_minutes`, `avg_effective_minutes`

### GET /api/stats/incomplete-students

获取未完成学生列表（最常用于发提醒）。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| course_id | query | 是 | 课程ID |

返回示例：
```json
{
  "code": 0,
  "data": {
    "course_title": "高中数学必修一 - 集合与函数",
    "incomplete": [
      { "user_id": 4, "name": "刘大伟", "class_name": "高一1班", "effective_minutes": 55.0 },
      { "user_id": 6, "name": "赵天宇", "class_name": "高一2班", "effective_minutes": 10.0 }
    ]
  }
}
```

---

## 通知相关

### POST /api/notify/study-reminder

向未完成学生发送钉钉学习提醒。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| course_id | body | 是 | 课程ID |

### POST /api/notify/daily-report

发送每日学习报告到钉钉群。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| course_id | body | 是 | 课程ID |

### GET /api/notify/export

导出学习进度 Excel 文件（返回 blob）。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| course_id | query | 是 | 课程ID |

返回：`application/vnd.openxmlformats-officedocument.spreadsheetml.sheet` 二进制流

---

## 用户管理

### GET /api/admin/users

获取用户列表。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| role | query | 否 | `student`/`teacher`/`admin` |
| class_name | query | 否 | 班级名 |
| search | query | 否 | 姓名搜索 |

### PUT /api/admin/users/{user_id}/role

修改用户角色。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| role | body | 是 | `student`/`teacher`/`admin` |

### POST /api/admin/users/{user_id}/set-password

设置用户密码。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| new_password | body | 是 | 新密码（至少6位） |

### POST /api/admin/users

创建新用户。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| name | body | 是 | 姓名 |
| role | body | 否 | 默认 student |
| class_name | body | 否 | 班级 |
| password | body | 否 | 初始密码，默认 123456 |

---

## 班级管理

### GET /api/admin/classes

获取班级列表（含学生/教师人数统计）。

权限要求：admin / teacher

返回示例：
```json
{
  "code": 0,
  "data": [
    {
      "class_name": "高一1班",
      "student_count": 30,
      "teacher_count": 2
    },
    {
      "class_name": "2026级高一新生",
      "student_count": 0,
      "teacher_count": 0
    }
  ]
}
```

说明：v5.0 起班级列表从 `class_defs` 表读取，支持空班级（创建后尚未分配学生）。

### POST /api/admin/classes

创建班级（支持空班级，无需分配学生即可存在）。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| class_name | body | 是 | 班级名称（唯一） |

权限要求：admin / teacher

返回示例：
```json
{
  "code": 0,
  "msg": "班级 '2026级高一新生' 创建成功"
}
```

### PUT /api/admin/classes/{class_name}

更新班级名称（批量修改该班级所有用户的 class_name + 更新 class_defs 表）。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| class_name | path | 是 | 原班级名称（URL编码） |
| new_name | body | 是 | 新班级名称 |

权限要求：仅 admin

### DELETE /api/admin/classes/{class_name}

删除班级（将该班级所有用户的 class_name 置空，并删除 class_defs 记录。不删除用户账号和学习数据）。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| class_name | path | 是 | 要删除的班级名称（URL编码） |

权限要求：仅 admin

### PUT /api/admin/classes/{class_name}/students

批量分配学生到指定班级（最常用的班级操作接口）。

| 参数 | 位置 | 必填 | 说明 |
|------|------|------|------|
| class_name | path | 是 | 目标班级名称 |
| user_ids | body | 是 | 用户ID列表，如 `[848, 849, 850]` |

权限要求：admin / teacher

返回示例：
```json
{
  "code": 0,
  "msg": "已将 768 名用户分配到班级 '2026级高一新生'"
}
```

说明：
- 已在其他班级的学生会被移动到新班级
- 适合大批量操作（数百人级别），单次请求即可完成

---

## 认证相关

### GET /api/auth/me

获取当前认证用户信息。

### GET /api/auth/api-key

查看 API Key 状态（掩码）。

### POST /api/auth/generate-api-key

生成/重新生成 API Key。

---

## 错误码

| HTTP 状态码 | 含义 |
|------------|------|
| 401 | 未认证（缺少 Key 或 Key 无效） |
| 403 | 权限不足（如学生调教师接口） |
| 404 | 资源不存在 |

业务错误通过 `code` 字段区分：`0`=成功，`1`=业务错误（见 `msg` 字段）